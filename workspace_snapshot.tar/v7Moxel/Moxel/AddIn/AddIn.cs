﻿using System;
using System.Runtime.InteropServices;
using AddIn;
using System.Reflection;
using System.Collections;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Moxel
{
    public sealed class AliasAttribute : Attribute
    {
        public string RussianName { get; set; }
        public AliasAttribute(string alias)
        {
            RussianName = alias;
        }
    }
    public abstract class AddIn : IInitDone, ILanguageExtender
    {
        /// <summary>ProgID COM-объекта компоненты</summary>
        string AddInName
        {
            get
            {
                return this.GetType().GetCustomAttribute<ProgIdAttribute>().Value.Replace("AddIn.", "");
            }
        }
        static AddIn()
        {
            Debug.WriteLine("LOAD");
        }

        /// <summary>Указатель на IDispatch</summary>
        static protected dynamic connect1c;

        /// <summary>Вызов событий 1С</summary>
        static protected IAsyncEvent asyncEvent;

        /// <summary>Статусная строка 1С</summary>
        static protected IStatusLine statusLine;

        /// <summary>Сообщения об ошибках 1С</summary>
        static protected IErrorLog errorLog;
        /// <summary>
        /// Коллекция интерфейсов
        /// </summary>
        private Type[] allInterfaceTypes;  
        /// <summary>
        /// Коллекция методов
        /// </summary>
        private MethodInfo[] allMethodInfo; 
        /// <summary>
        /// Коллекция свойств
        /// </summary>
        private PropertyInfo[] allPropertyInfo;
        /// <summary>
        /// метод - идентификатор
        /// </summary>
        private Hashtable nameToNumber;
        /// <summary>
        /// идентификатор - метод
        /// </summary>
        private Hashtable numberToName;  
        /// <summary>
        /// количество параметров метода
        /// </summary>
        private Hashtable numberToParams;
        /// <summary>
        /// имеет возвращаемое значение (является функцией)
        /// </summary>
        private Hashtable numberToRetVal;
        /// <summary>
        /// свойство - идентификатор
        /// </summary>
        private Hashtable propertyNameToNumber;
        /// <summary>
        /// идентификатор - свойство
        /// </summary>
        private Hashtable propertyNumberToName;
        /// <summary>
        /// номер метода - индекс в массиве методов
        /// </summary>
        private Hashtable numberToMethodInfoIdx;
        /// <summary>
        /// номер свойства - индекс в массиве свойств
        /// </summary>
        private Hashtable propertyNumberToPropertyInfoIdx; 

        public delegate IntPtr dGetMainFrame();
        
        /// <summary>
        /// GetMainFrame
        /// 
        /// </summary>
        public static dGetMainFrame GetMainFrame = WinApi.GetDelegate<dGetMainFrame>("frame.dll", "?GetMainFrame@@YAPAVCMDIFrameWnd@@XZ");

        public enum MessageMarker
        {
            None = 0,
            BlueTriangle,
            Exclamation,
            Exclamation2,
            Exclamation3,
            Information,
            BlackErr,
            RedErr,
            MetaData,
            UnderlinedErr
        };

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Ansi, ThrowOnUnmappableChar = true)]
        protected delegate IntPtr dGetExecutedModule();

        protected static dGetExecutedModule GetBkendUi = WinApi.GetDelegate<dGetExecutedModule>("bkend.dll", "?GetBkEndUI@@YAPAVCBkEndUI@@XZ");
        protected static dGetExecutedModule GetExecutedModule = WinApi.GetDelegate<dGetExecutedModule>("blang.dll", "?GetExecutedModule@CBLModule@@SAPAV1@XZ");

        [UnmanagedFunctionPointer(CallingConvention.ThisCall, CharSet = CharSet.Auto, ThrowOnUnmappableChar = true)]
        protected delegate void dDoMessageLine(IntPtr _this, IntPtr ErrorMessage, MessageMarker Flag);

        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi, ThrowOnUnmappableChar = true)]
        protected delegate void dAfxThrowOleDispatchException(int a1, [MarshalAs(UnmanagedType.LPStr)] string ErrorMessage, int Flag);
        protected static dAfxThrowOleDispatchException AfxThrowOleDispatchException = MFCNative.GetDelegate<dAfxThrowOleDispatchException>(1268);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Auto, ThrowOnUnmappableChar = true)]
        protected delegate void dRaiseExtRuntimeError([MarshalAs(UnmanagedType.LPStr)] string ErrorMessage, MessageMarker Flag);
        protected static dRaiseExtRuntimeError RaiseExtRuntimeErrorNative = WinApi.GetDelegate<dRaiseExtRuntimeError>("blang.dll", "?RaiseExtRuntimeError@CBLModule@@SAXPBDH@Z");


        [UnmanagedFunctionPointer(CallingConvention.ThisCall, CharSet = CharSet.Ansi, ThrowOnUnmappableChar = true)]
        protected delegate void dCBLModule__Reset(IntPtr _this);
        protected dCBLModule__Reset OnRuntimeError = WinApi.GetDelegate<dCBLModule__Reset>("blang.dll", "?OnRuntimeError@CBLModule@@UAEHXZ");

        /// <summary>
        /// AfxGetMainWnd
        /// </summary>
        public static dGetMainFrame GetMainWindow = MFCNative.GetDelegate<dGetMainFrame>(6575);


        protected string ErrorDescription = null;
        protected string ErrorStackTrace = null;

        protected abstract HRESULT OnRegister();
        protected abstract void OnInit();
        protected abstract void OnDone();

        static int refCount = 0;
        /// <summary>
        /// Получает главное окно 1С
        /// </summary>
        /// <returns>IntPtr hWnd</returns>
        public static IntPtr Get1CWindow()
        {
            if (GetMainFrame == null)
                return IntPtr.Zero;

            return Marshal.ReadIntPtr(GetMainFrame(), 32);
        }

        /// <summary>
        /// Возвращает MDI контейнер 1С
        /// </summary>
        /// <returns></returns>
        public static IntPtr Get1CMDIWindow()
        {
            if (GetMainFrame == null)
                return IntPtr.Zero;

            return Marshal.ReadIntPtr(GetMainFrame(), 192);
        }

        static IntPtr MainWindow = IntPtr.Zero;

        /// <summary>
        /// Устанавливает строку статуса. 
        /// </summary>
        /// <param name="message"></param>
        public static void StatusLine(string message)
        {
            if (MainWindow == IntPtr.Zero)
                MainWindow = Get1CWindow();

            if (MainWindow != IntPtr.Zero)
                Task.Run(() => WinApi.SendMessage(Get1CWindow(), 866, 0, message));
        }

        /// <summary>
        /// Событие изменения прогресса
        /// </summary>
        /// <param name="progress"></param>
        private static void Writer_onProgress(int progress)
        {
            StatusLine($"{progress:D2}%");
            Application.DoEvents();
        }

        public void PostException(Exception ex)
        {

            if (connect1c == null)
                return;

            object[] param = { 1006, AddInName, ex.Message, 1};

            var tt = connect1c.GetType().InvokeMember("AddError", BindingFlags.InvokeMethod, null, connect1c, param);
        }

        #region IInitDone

        static Exception getInternalEx(Exception ex)
        {
            if (ex.InnerException != null)
                return getInternalEx(ex.InnerException);
            return ex;
        }

        HRESULT IInitDone.Init([MarshalAs(UnmanagedType.IDispatch)] dynamic connection)
        {
            Exception ex = null;
            try
            {
                connect1c = connection;
                if (errorLog == null)
                    errorLog = (IErrorLog)connection;

                if (statusLine == null)
                {
                    statusLine = (IStatusLine)connection;
                    ExcelWriter.OnProgress += Writer_onProgress;
                    HtmlWriter.onProgress += Writer_onProgress;
                    PDFWriter.onProgress += Writer_onProgress;
                }

                if (asyncEvent == null)
                    asyncEvent = (IAsyncEvent)connection;

                OnInit();
                refCount++;
                return HRESULT.S_OK;
            }
            catch(Exception e)
            {
                try
                {
                    RaiseExtRuntimeErrorNative(getInternalEx(e).Message, MessageMarker.None);
                }
                catch 
                {
                }

                return HRESULT.E_FAIL;
            }
            finally
            {
                if (ex != null && errorLog != null)
                {
  
                    ex = getInternalEx(ex);

                    System.Runtime.InteropServices.ComTypes.EXCEPINFO ei = new System.Runtime.InteropServices.ComTypes.EXCEPINFO()
                    {
                        bstrDescription = ex.Message,
                        bstrSource = ex.StackTrace,
                        scode = ex.HResult,
                        bstrHelpFile = ex.HelpLink,
                    };


                    errorLog.AddError(this.AddInName, ref ei);
                    ex = null;
                }
            }



        }
        HRESULT IInitDone.GetInfo([MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref object[] info)
        {
            info[0] = 2000;
            return HRESULT.S_OK;
        }
        HRESULT IInitDone.Done()
        {

            OnDone();

            if (--refCount == 0)
            {
                try
                {
                    if (statusLine != null)
                    {
                        Marshal.FinalReleaseComObject(statusLine);
                        statusLine = null;
                    }

                    if (errorLog != null)
                    {
                        Marshal.FinalReleaseComObject(errorLog);
                        errorLog = null;
                    }

                    if (asyncEvent != null)
                    {
                        Marshal.FinalReleaseComObject(asyncEvent);
                        asyncEvent = null;
                    }

                    connect1c = null;
                }
                catch(Exception ex) 
                {
                    Debug.WriteLine(ex.ToString());
                }
            }

            // РЕФАКТОРИНГ (п.1): вместо двух принудительных GC.Collect — один сбор за
            // мусором после освобождения COM-объектов; двойной Collect + WaitForPendingFinalizers
            // на выгрузке аддина избыточен и подвешивал поток 1С.
            GC.Collect();
            Marshal.CleanupUnusedObjectsInCurrentContext();
            return HRESULT.S_OK;
        }
        #endregion

        #region ILAnguageExtender
        HRESULT ILanguageExtender.CallAsFunc(int methodNum, [MarshalAs(UnmanagedType.Struct)] ref object retValue, [In, Out, MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref object[] pParams)
        {
            retValue = "";
            try
            {
                retValue = allMethodInfo[(int)numberToMethodInfoIdx[methodNum]].Invoke(this, pParams);
                return HRESULT.S_OK;
            }

            catch (Exception e)
            {
                while (e.InnerException != null)
                    e = e.InnerException;

                ErrorDescription = e.Message;
                ErrorStackTrace = e.StackTrace;

                Converter.RaiseExtRuntimeError(e.Message);
                pParams = null;
                return HRESULT.E_FAIL;
            }
            
        }
        HRESULT ILanguageExtender.CallAsProc(int methodNum, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] ref object[] pParams)
        {
            try
            {
                allMethodInfo[(int)numberToMethodInfoIdx[methodNum]].Invoke(this, pParams);
            }
            catch (Exception e)
            {
                ErrorDescription = e.InnerException.Message;
                pParams = null;
                return HRESULT.E_FAIL;
            }
            return HRESULT.S_OK;
        }
        HRESULT ILanguageExtender.FindMethod([MarshalAs(UnmanagedType.BStr)] string methodName, ref int methodNUm)
        {
            if (nameToNumber.ContainsKey(methodName.ToUpper()))
            {
                methodNUm = (int)nameToNumber[methodName.ToUpper()];
                return HRESULT.S_OK;
            }

            methodNUm = -1;
            return HRESULT.S_FALSE;
        }
        HRESULT ILanguageExtender.FindProp([MarshalAs(UnmanagedType.BStr)] string propName, ref Int32 propNum)
        {
            if (propertyNameToNumber.ContainsKey(propName.ToUpper()))
            {
                propNum = (Int32)propertyNameToNumber[propName.ToUpper()];
                return HRESULT.S_OK;
            }

            propNum = -1;
            return HRESULT.S_FALSE;
        }
        HRESULT ILanguageExtender.GetMethodName(int methodNum, int methodAlias, [MarshalAs(UnmanagedType.BStr)] ref string methodName)
        {
            if (numberToName.ContainsKey(methodNum))
            {
                methodName = (String)numberToName[methodNum];
                return HRESULT.S_OK;
            }
            return HRESULT.S_FALSE;

        }
        HRESULT ILanguageExtender.GetNMethods(ref Int32 pMethods)
        {
            pMethods = allMethodInfo.Length;
            return HRESULT.S_OK;
        }
        HRESULT ILanguageExtender.GetNParams(int methodNum, ref int pParams)
        {
            if (numberToParams.ContainsKey(methodNum))
            {
                pParams = (Int32)numberToParams[methodNum];
                return HRESULT.S_OK;
            }

            pParams = -1;
            return HRESULT.S_FALSE;
        }
        HRESULT ILanguageExtender.GetNProps(ref int props)
        {
            props = (Int32)propertyNameToNumber.Count;
            return HRESULT.S_OK;
        }
        HRESULT ILanguageExtender.GetParamDefValue(int methodNum, int paramNum, [MarshalAs(UnmanagedType.Struct)] ref object paramDefValue)
        {
            return HRESULT.S_OK;
        }
        HRESULT ILanguageExtender.GetPropName(int propNum, int propAlias, [MarshalAs(UnmanagedType.BStr)] ref string propName)
        {
            if (propertyNumberToName.ContainsKey(propNum))
            {
                propName = (String)propertyNumberToName[propNum];
                return HRESULT.S_OK;
            }
            return HRESULT.S_FALSE;
        }
        HRESULT ILanguageExtender.GetPropVal(int propNum, [MarshalAs(UnmanagedType.Struct)] ref object propVal)
        {
            propVal = allPropertyInfo[propNum].GetValue(this, null);
            return HRESULT.S_OK;
        }
        HRESULT ILanguageExtender.HasRetVal(int methodNum, ref bool retValue)
        {
            if (numberToRetVal.ContainsKey(methodNum))
            {
                retValue = (bool)numberToRetVal[methodNum];
                return HRESULT.S_OK;
            }

            return HRESULT.S_FALSE;
        }
        HRESULT ILanguageExtender.IsPropReadable(int propNum, ref bool propRead)
        {
            propRead = allPropertyInfo[(int)propertyNumberToPropertyInfoIdx[propNum]].CanRead;
            return HRESULT.S_OK;
        }
        HRESULT ILanguageExtender.IsPropWritable(int propNum, ref bool propWrite)
        {
            propWrite = allPropertyInfo[(int)propertyNumberToPropertyInfoIdx[propNum]].CanWrite;
            return HRESULT.S_OK;
        }
        HRESULT ILanguageExtender.RegisterExtensionAs([In, Out, MarshalAs(UnmanagedType.BStr)] ref string extensionName)
        {
            try
            {
                Type type = this.GetType();

                allInterfaceTypes = type.GetInterfaces();
                allMethodInfo = type.GetMethods();
                allPropertyInfo = type.GetProperties();

                // Хэш-таблицы с именами методов и свойств компоненты
                nameToNumber = new Hashtable();
                numberToName = new Hashtable();
                numberToParams = new Hashtable();
                numberToRetVal = new Hashtable();
                propertyNameToNumber = new Hashtable();
                propertyNumberToName = new Hashtable();
                numberToMethodInfoIdx = new Hashtable();
                propertyNumberToPropertyInfoIdx = new Hashtable();

                int Identifier = 0;

                foreach (Type interfaceType in allInterfaceTypes)
                {
                    // Интересуют только методы в пользовательских интерфейсах, стандартные пропускаем
                    if ( interfaceType.Name.Equals("IDisposable")
                      || interfaceType.Name.Equals("IManagedObject")
                      || interfaceType.Name.Equals("IRemoteDispatch")
                      || interfaceType.Name.Equals("IServicedComponentInfo")
                      || interfaceType.Name.Equals(nameof(IInitDone))
                      || interfaceType.Name.Equals(nameof(ILanguageExtender)))
                    {
                        continue;
                    };

                    // Обработка методов интерфейса
                    MethodInfo[] interfaceMethods = interfaceType.GetMethods();
                    foreach (MethodInfo interfaceMethodInfo in interfaceMethods)
                    {
                        if (interfaceMethodInfo.IsSpecialName)
                            continue;
                        string alias = ((AliasAttribute)Attribute.GetCustomAttribute(interfaceMethodInfo, typeof(AliasAttribute))).RussianName.ToUpper();

                        nameToNumber.Add(interfaceMethodInfo.Name.ToUpper(), Identifier);
                        numberToName.Add(Identifier, interfaceMethodInfo.Name);
                        numberToParams.Add(Identifier, interfaceMethodInfo.GetParameters().Length);
                        numberToRetVal.Add(Identifier, (interfaceMethodInfo.ReturnType != typeof(void)));
                        if (!string.IsNullOrWhiteSpace(alias))
                        {
                            nameToNumber.Add(alias, Identifier);
                        }
                        Identifier++;
                    }

                    Identifier = 0;
                    // Обработка свойств интерфейса
                    PropertyInfo[] interfaceProperties = interfaceType.GetProperties();
                    foreach (PropertyInfo interfacePropertyInfo in interfaceProperties)
                    {
                        string alias = ((AliasAttribute)Attribute.GetCustomAttribute(interfacePropertyInfo, typeof(AliasAttribute))).RussianName;

                        propertyNameToNumber.Add(interfacePropertyInfo.Name.ToUpper(), Identifier);

                        if (!string.IsNullOrWhiteSpace(alias))
                            propertyNameToNumber.Add(alias.ToUpper(), Identifier);

                        if (!string.IsNullOrWhiteSpace(alias))
                            propertyNumberToName.Add(Identifier, alias);
                        else
                            propertyNumberToName.Add(Identifier, interfacePropertyInfo.Name);
                        



                        Identifier++;
                    }
                }

                // Отображение номера метода на индекс в массиве
                foreach (DictionaryEntry entry in numberToName)
                {
                    bool found = false;
                    for (int ii = 0; ii < allMethodInfo.Length; ii++)
                    {
                        if (allMethodInfo[ii].Name.Equals(entry.Value.ToString()))
                        {
                            numberToMethodInfoIdx.Add(entry.Key, ii);
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        throw new COMException("Метод " + entry.Value.ToString() + " не реализован");
                }

                // Отображение номера свойства на индекс в массиве
                foreach (DictionaryEntry entry in propertyNumberToName)
                {
                    bool found = false;
                    for (int ii = 0; ii < allPropertyInfo.Length; ii++)
                    {
                        if (allPropertyInfo[ii].Name.Equals(entry.Value.ToString()))
                        {
                            propertyNumberToPropertyInfoIdx.Add(entry.Key, ii);
                            found = true;
                            break;
                        }

                        if (propertyNameToNumber.ContainsKey(entry.Value.ToString().ToUpper()))
                        {
                            propertyNumberToPropertyInfoIdx.Add(entry.Key, propertyNameToNumber[entry.Value.ToString().ToUpper()]);
                            found = true;
                            break;
                        };
                    }
                    if (!found && !propertyNameToNumber.ContainsKey(entry.Value.ToString().ToUpper()))
                        throw new COMException("Свойство " + entry.Value.ToString() + " не реализовано");
                }

                // Компонент инициализирован успешно. Возвращаем имя компонента.
                extensionName = AddInName;
            }
            catch (Exception e)
            {
                Debug.Print($"Error: {e}");
                return HRESULT.S_FALSE;
            }

            return OnRegister();
            
        }
        [ComVisible(true)]
        HRESULT ILanguageExtender.SetPropVal(int propNum, [MarshalAs(UnmanagedType.Struct)] ref object propVal)
        {
            allPropertyInfo[(int)propertyNumberToPropertyInfoIdx[propNum]].SetValue(this, propVal, null);
            return HRESULT.S_OK;
        }
        #endregion
    }
}
